/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 92.98764572820602, "KoPercent": 7.0123542717939795};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4649382286410301, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.4649382286410301, 500, 1500, "HTTP Request"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 5747, 403, 7.0123542717939795, 596.5512441273703, 510, 2753, 526.0, 537.0, 1529.0, 1541.0, 19.065849669408053, 16.630250718245424, 4.390360038143311], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["HTTP Request", 5747, 403, 7.0123542717939795, 596.5512441273703, 510, 2753, 526.0, 537.0, 1529.0, 1541.0, 19.065849669408053, 16.630250718245424, 4.390360038143311], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,526 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 9, 2.2332506203473947, 0.15660344527579606], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,549 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 5, 1.2406947890818858, 0.08700191404210893], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,537 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 11, 2.729528535980149, 0.19140421089263965], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,539 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 18, 4.4665012406947895, 0.3132068905515921], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,525 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 7, 1.7369727047146402, 0.1218026796589525], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,548 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 1, 0.24813895781637718, 0.017400382808421787], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,516 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 1, 0.24813895781637718, 0.017400382808421787], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,527 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 11, 2.729528535980149, 0.19140421089263965], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,538 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 21, 5.2109181141439205, 0.3654080389768575], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,545 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 5, 1.2406947890818858, 0.08700191404210893], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,522 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 5, 1.2406947890818858, 0.08700191404210893], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,533 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 23, 5.707196029776675, 0.40020880459370106], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,546 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 7, 1.7369727047146402, 0.1218026796589525], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,534 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 17, 4.218362282878412, 0.29580650774317035], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,547 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 5, 1.2406947890818858, 0.08700191404210893], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,524 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 9, 2.2332506203473947, 0.15660344527579606], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,536 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 16, 3.970223325062035, 0.2784061249347486], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 2,753 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 1, 0.24813895781637718, 0.017400382808421787], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,594 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 1, 0.24813895781637718, 0.017400382808421787], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,523 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 16, 3.970223325062035, 0.2784061249347486], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,535 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 27, 6.699751861042183, 0.4698103358273882], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,541 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 13, 3.225806451612903, 0.2262049765094832], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,553 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 1, 0.24813895781637718, 0.017400382808421787], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,552 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 2, 0.49627791563275436, 0.034800765616843574], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,542 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 8, 1.9851116625310175, 0.1392030624673743], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,540 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 15, 3.7220843672456576, 0.26100574212632677], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,531 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 22, 5.459057071960298, 0.3828084217852793], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,543 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 5, 1.2406947890818858, 0.08700191404210893], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,551 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 3, 0.7444168734491315, 0.052201148425265353], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,520 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 6, 1.488833746898263, 0.10440229685053071], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,532 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 26, 6.451612903225806, 0.4524099530189664], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,544 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 6, 1.488833746898263, 0.10440229685053071], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,521 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 10, 2.4813895781637716, 0.17400382808421785], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,550 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 1, 0.24813895781637718, 0.017400382808421787], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,518 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 4, 0.9925558312655087, 0.06960153123368715], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,519 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 1, 0.24813895781637718, 0.017400382808421787], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,528 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 18, 4.4665012406947895, 0.3132068905515921], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,517 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 1, 0.24813895781637718, 0.017400382808421787], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,530 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 22, 5.459057071960298, 0.3828084217852793], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 2,416 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 1, 0.24813895781637718, 0.017400382808421787], "isController": false}, {"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,529 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 22, 5.459057071960298, 0.3828084217852793], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 5747, 403, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,535 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 27, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,532 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 26, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,533 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 23, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,531 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 22, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,530 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 22], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["HTTP Request", 5747, 403, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,535 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 27, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,532 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 26, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,533 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 23, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,531 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 22, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 1,530 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 1,500 milisegundos.", 22], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
